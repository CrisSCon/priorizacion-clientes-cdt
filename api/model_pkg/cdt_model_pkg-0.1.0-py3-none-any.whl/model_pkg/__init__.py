"""Local model inference package."""
